from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import logging
import argparse
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Define schema for different event types
user_event_schema = StructType([
    StructField("event_id", StringType(), True),
    StructField("event_type", StringType(), True),
    StructField("user_id", StringType(), True),
    StructField("product_id", StringType(), True),
    StructField("timestamp", StringType(), True),
    StructField("session_id", StringType(), True)
])

order_event_schema = StructType([
    StructField("order_id", StringType(), True),
    StructField("user_id", StringType(), True),
    StructField("timestamp", StringType(), True),
    StructField("items", ArrayType(
        StructType([
            StructField("product_id", StringType(), True),
            StructField("quantity", IntegerType(), True),
            StructField("unit_price", DoubleType(), True),
            StructField("total", DoubleType(), True)
        ])
    ), True),
    StructField("total_amount", DoubleType(), True),
    StructField("shipping_address", StringType(), True),
    StructField("payment_method", StringType(), True),
    StructField("status", StringType(), True)
])

inventory_event_schema = StructType([
    StructField("inventory_event_id", StringType(), True),
    StructField("product_id", StringType(), True),
    StructField("timestamp", StringType(), True),
    StructField("change_type", StringType(), True),
    StructField("quantity_change", IntegerType(), True),
    StructField("new_quantity", IntegerType(), True),
    StructField("warehouse_id", StringType(), True),
    StructField("reason", StringType(), True)
])

def create_spark_session(app_name):
    """Create a Spark session with necessary configurations"""
    spark = SparkSession.builder \
        .appName(app_name) \
        .config("spark.streaming.stopGracefullyOnShutdown", "true") \
        .config("spark.sql.streaming.schemaInference", "true") \
        .config("spark.sql.shuffle.partitions", "10") \
        .config("spark.streaming.kafka.maxRatePerPartition", "100") \
        .config("spark.default.parallelism", "20") \
        .getOrCreate()
    
    # Set log level
    spark.sparkContext.setLogLevel("WARN")
    
    return spark

def read_kafka_stream(spark, kafka_bootstrap_servers, topic, schema):
    """Read a stream from Kafka with the given schema"""
    return spark.readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", kafka_bootstrap_servers) \
        .option("subscribe", topic) \
        .option("startingOffsets", "latest") \
        .option("failOnDataLoss", "false") \
        .load() \
        .selectExpr("CAST(value AS STRING) as json_data") \
        .select(from_json("json_data", schema).alias("data")) \
        .select("data.*")

def process_user_events(df):
    """Process user events to extract real-time metrics"""
    # Convert timestamp string to timestamp
    df = df.withColumn("event_timestamp", to_timestamp("timestamp"))
    
    # Add processing time
    df = df.withColumn("processing_time", current_timestamp())
    
    # Event counts by type in 5-minute windows
    event_counts = df \
        .withWatermark("event_timestamp", "10 minutes") \
        .groupBy(
            window("event_timestamp", "5 minutes"),
            "event_type"
        ) \
        .count() \
        .select(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("event_type"),
            col("count").alias("event_count")
        )
    
    # User engagement - unique users per event type in 5-minute windows
    # Changed countDistinct to approx_count_distinct for streaming
    user_engagement = df \
        .withWatermark("event_timestamp", "10 minutes") \
        .groupBy(
            window("event_timestamp", "5 minutes"),
            "event_type"
        ) \
        .agg(approx_count_distinct("user_id").alias("unique_users")) \
        .select(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("event_type"),
            col("unique_users")
        )
    
    # Product popularity - most viewed/interacted products
    product_popularity = df \
        .withWatermark("event_timestamp", "10 minutes") \
        .filter(col("event_type").isin("page_view", "product_click", "add_to_cart")) \
        .groupBy(
            window("event_timestamp", "5 minutes"),
            "product_id"
        ) \
        .count() \
        .select(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("product_id"),
            col("count").alias("interaction_count")
        )
    
    # Add to cart conversion rate
    # First, count product views
    product_views = df \
        .withWatermark("event_timestamp", "30 minutes") \
        .filter(col("event_type") == "page_view") \
        .groupBy(
            window("event_timestamp", "15 minutes"),
            "product_id"
        ) \
        .count() \
        .select(
            col("window").alias("view_window"),
            col("product_id"),
            col("count").alias("view_count")
        )
    
    # Then count add to cart events
    add_to_carts = df \
        .withWatermark("event_timestamp", "30 minutes") \
        .filter(col("event_type") == "add_to_cart") \
        .groupBy(
            window("event_timestamp", "15 minutes"),
            "product_id"
        ) \
        .count() \
        .select(
            col("window").alias("cart_window"),
            col("product_id"),
            col("count").alias("cart_count")
        )
    
    return {
        "user_events_enriched": df,
        "event_counts": event_counts,
        "user_engagement": user_engagement,
        "product_popularity": product_popularity,
        "product_views": product_views,
        "add_to_carts": add_to_carts
    }

def process_order_events(df):
    """Process order events to extract real-time metrics"""
    # Convert timestamp string to timestamp
    df = df.withColumn("order_timestamp", to_timestamp("timestamp"))
    
    # Add processing time
    df = df.withColumn("processing_time", current_timestamp())
    
    # Explode the items array to analyze individual items
    items_df = df.select(
        "order_id",
        "user_id",
        "order_timestamp",
        "payment_method",
        explode("items").alias("item")
    ).select(
        "order_id",
        "user_id",
        "order_timestamp",
        "payment_method",
        "item.product_id",
        "item.quantity",
        "item.unit_price",
        "item.total"
    )
    
    # Sales by product in 5-minute windows
    sales_by_product = items_df \
        .withWatermark("order_timestamp", "10 minutes") \
        .groupBy(
            window("order_timestamp", "5 minutes"),
            "product_id"
        ) \
        .agg(
            sum("quantity").alias("total_quantity"),
            sum("total").alias("total_sales")
        ) \
        .select(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("product_id"),
            col("total_quantity"),
            col("total_sales")
        )
    
    # Revenue by payment method
    revenue_by_payment = df \
        .withWatermark("order_timestamp", "10 minutes") \
        .groupBy(
            window("order_timestamp", "5 minutes"),
            "payment_method"
        ) \
        .agg(
            count("order_id").alias("order_count"),
            sum("total_amount").alias("total_revenue")
        ) \
        .select(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("payment_method"),
            col("order_count"),
            col("total_revenue")
        )
    
    # Average order value
    average_order_value = df \
        .withWatermark("order_timestamp", "10 minutes") \
        .groupBy(
            window("order_timestamp", "5 minutes")
        ) \
        .agg(
            count("order_id").alias("order_count"),
            avg("total_amount").alias("average_order_value"),
            sum("total_amount").alias("total_revenue")
        ) \
        .select(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("order_count"),
            col("average_order_value"),
            col("total_revenue")
        )
    
    return {
        "orders_enriched": df,
        "order_items": items_df,
        "sales_by_product": sales_by_product,
        "revenue_by_payment": revenue_by_payment,
        "average_order_value": average_order_value
    }

def process_inventory_events(df):
    """Process inventory events to extract real-time metrics"""
    # Convert timestamp string to timestamp
    df = df.withColumn("inventory_timestamp", to_timestamp("timestamp"))
    
    # Add processing time
    df = df.withColumn("processing_time", current_timestamp())
    
    # Inventory changes by product
    inventory_changes = df \
        .withWatermark("inventory_timestamp", "10 minutes") \
        .groupBy(
            window("inventory_timestamp", "5 minutes"),
            "product_id"
        ) \
        .agg(
            sum("quantity_change").alias("net_quantity_change"),
            max("new_quantity").alias("current_quantity"),
            count("inventory_event_id").alias("update_count")
        ) \
        .select(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("product_id"),
            col("net_quantity_change"),
            col("current_quantity"),
            col("update_count")
        )
    
    # Inventory alerts for low stock
    low_stock_alerts = df \
        .filter(col("new_quantity") < 10) \
        .withWatermark("inventory_timestamp", "10 minutes") \
        .groupBy(
            window("inventory_timestamp", "5 minutes"),
            "product_id"
        ) \
        .agg(
            min("new_quantity").alias("min_quantity"),
            max("new_quantity").alias("max_quantity")
        ) \
        .select(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("product_id"),
            col("min_quantity"),
            col("max_quantity")
        )
    
    return {
        "inventory_enriched": df,
        "inventory_changes": inventory_changes,
        "low_stock_alerts": low_stock_alerts
    }

def calculate_cross_stream_metrics(user_views, add_to_carts, sales_by_product):
    """Calculate metrics that require data from multiple streams"""
    # Add to cart conversion rate
    # This needs to be calculated in a batch job using the user_views and add_to_carts outputs
    pass

def write_stream_to_console(df, output_mode="append"):
    """Write stream to console for development purposes"""
    return df.writeStream \
        .outputMode(output_mode) \
        .format("console") \
        .option("truncate", "false") \
        .start()

def write_stream_to_memory(df, table_name, output_mode="append"):
    """Write stream to memory table for interactive queries"""
    return df.writeStream \
        .outputMode(output_mode) \
        .format("memory") \
        .queryName(table_name) \
        .start()

def write_stream_to_file(df, output_path, checkpoint_path, output_mode="append"):
    """Write stream to parquet files"""
    return df.writeStream \
        .outputMode(output_mode) \
        .format("parquet") \
        .option("path", output_path) \
        .option("checkpointLocation", checkpoint_path) \
        .partitionBy("window_start") \
        .start()

def main():
    """Main function to run the Spark Streaming application"""
    parser = argparse.ArgumentParser(description="Spark Streaming for E-commerce Analytics")
    
    parser.add_argument("--kafka_bootstrap_servers", required=True, help="Kafka bootstrap servers")
    parser.add_argument("--output_path", required=True, help="Base output path for saving results")
    parser.add_argument("--checkpoint_path", required=True, help="Base checkpoint path")
    parser.add_argument("--mode", default="local", help="Run mode: local, development, or production")
    
    args = parser.parse_args()
    
    # Create Spark session
    spark = create_spark_session("EcommerceAnalytics")
    
    # Read streams from Kafka
    user_events_df = read_kafka_stream(
        spark, 
        args.kafka_bootstrap_servers, 
        "user_events", 
        user_event_schema
    )
    
    order_events_df = read_kafka_stream(
        spark, 
        args.kafka_bootstrap_servers, 
        "order_events", 
        order_event_schema
    )
    
    inventory_events_df = read_kafka_stream(
        spark, 
        args.kafka_bootstrap_servers, 
        "inventory_events", 
        inventory_event_schema
    )
    
    # Process streams
    user_results = process_user_events(user_events_df)
    order_results = process_order_events(order_events_df)
    inventory_results = process_inventory_events(inventory_events_df)
    
    # Handle output based on mode
    queries = []
    
    if args.mode == "local" or args.mode == "development":
        # Write to memory and console for development
        for name, df in user_results.items():
            if name != "user_events_enriched":  # Skip the enriched events to reduce memory usage
                queries.append(write_stream_to_memory(df, f"user_{name}"))
            if name in ["event_counts", "user_engagement", "product_popularity"]:
                queries.append(write_stream_to_console(df))
        
        for name, df in order_results.items():
            if name != "orders_enriched" and name != "order_items":  # Skip raw data to reduce memory
                queries.append(write_stream_to_memory(df, f"order_{name}"))
            if name in ["sales_by_product", "revenue_by_payment", "average_order_value"]:
                queries.append(write_stream_to_console(df))
        
        for name, df in inventory_results.items():
            if name != "inventory_enriched":  # Skip raw data to reduce memory
                queries.append(write_stream_to_memory(df, f"inventory_{name}"))
            if name in ["inventory_changes", "low_stock_alerts"]:
                queries.append(write_stream_to_console(df))
    
    if args.mode == "production" or args.mode == "development":
        # Write to files for production
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # User metrics
        for name, df in user_results.items():
            if name in ["event_counts", "user_engagement", "product_popularity"]:
                output_path = f"{args.output_path}/user_{name}/{timestamp}"
                checkpoint_path = f"{args.checkpoint_path}/user_{name}/{timestamp}"
                queries.append(write_stream_to_file(df, output_path, checkpoint_path))
        
        # Order metrics
        for name, df in order_results.items():
            if name in ["sales_by_product", "revenue_by_payment", "average_order_value"]:
                output_path = f"{args.output_path}/order_{name}/{timestamp}"
                checkpoint_path = f"{args.checkpoint_path}/order_{name}/{timestamp}"
                queries.append(write_stream_to_file(df, output_path, checkpoint_path))
        
        # Inventory metrics
        for name, df in inventory_results.items():
            if name in ["inventory_changes", "low_stock_alerts"]:
                output_path = f"{args.output_path}/inventory_{name}/{timestamp}"
                checkpoint_path = f"{args.checkpoint_path}/inventory_{name}/{timestamp}"
                queries.append(write_stream_to_file(df, output_path, checkpoint_path))
    
    # Wait for any query to terminate
    for query in queries:
        query.awaitTermination()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.error(f"Error in Spark Streaming application: {str(e)}", exc_info=True)