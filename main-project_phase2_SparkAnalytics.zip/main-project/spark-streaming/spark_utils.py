def setup_spark():
    """Set up directories and start the Spark streaming container"""
    try:
        # Create necessary directories inside spark-streaming folder
        logger.info("Creating necessary directories...")
        spark_dir = "spark-streaming"
        os.makedirs(os.path.join(spark_dir, "data", "output"), exist_ok=True)
        os.makedirs(os.path.join(spark_dir, "data", "checkpoint"), exist_ok=True)
        os.makedirs(os.path.join(spark_dir, "logs"), exist_ok=True)
        
        # Build and start the Spark streaming container
        logger.info("Building and starting Spark streaming container...")
        subprocess.run(["docker-compose", "up", "-d", "spark-streaming"], check=True)
        
        # Check logs
        logger.info("Checking Spark streaming logs...")
        time.sleep(5)
        subprocess.run(["docker-compose", "logs", "spark-streaming"], check=True)
        
        logger.info("Spark streaming job is running!")
        logger.info("You can access the Spark UI at http://localhost:4040")
        logger.info("To see continuous logs, run: docker-compose logs -f spark-streaming")
        
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed: {e}")
    except Exception as e:
        logger.error(f"Error setting up Spark: {e}")