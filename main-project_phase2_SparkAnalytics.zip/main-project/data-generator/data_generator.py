import json
import random
import time
import os
from datetime import datetime
from faker import Faker
from faker_commerce import Provider
from kafka import KafkaProducer
import uuid
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Faker with commerce provider
fake = Faker()
fake.add_provider(Provider)

class EcommerceDataGenerator:
    def __init__(self, bootstrap_servers):
        logger.info(f"Connecting to Kafka at {bootstrap_servers}")
        
        # More reasonable producer configuration
        self.producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            value_serializer=lambda x: json.dumps(x).encode('utf-8'),
            compression_type='gzip',
            batch_size=16384,  # 16KB batch size
            linger_ms=50,      # Wait 50ms to batch messages
            max_request_size=1048576,  # 1MB max request size
            buffer_memory=33554432,    # 32MB buffer
            acks='1',          # Wait for leader acknowledgment
            retries=3,
            retry_backoff_ms=100
        )
        
        logger.info("Generating sample data")
        # Initialize sample data - reduced product and user counts for testing
        self.products = self._generate_sample_products(20)
        self.users = self._generate_sample_users(50)
        logger.info(f"Generated {len(self.products)} products and {len(self.users)} users")
        
    def _generate_sample_products(self, num_products):
        return [{
            'product_id': str(uuid.uuid4()),
            'name': fake.ecommerce_name(),
            'category': fake.ecommerce_category(),
            'price': round(random.uniform(10, 1000), 2),
            'inventory': random.randint(0, 100)
        } for _ in range(num_products)]
    
    def _generate_sample_users(self, num_users):
        return [{
            'user_id': str(uuid.uuid4()),
            'name': fake.name(),
            'email': fake.email(),
            'location': fake.city()
        } for _ in range(num_users)]

    def generate_user_event(self):
        """Generate user browsing and interaction events"""
        user = random.choice(self.users)
        product = random.choice(self.products)
        event_type = random.choice([
            'page_view', 'search', 'add_to_cart', 'remove_from_cart',
            'add_to_wishlist', 'product_click', 'category_view'
        ])
        
        # Simplified event with smaller size
        return {
            'event_id': str(uuid.uuid4()),
            'event_type': event_type,
            'user_id': user['user_id'],
            'product_id': product['product_id'],
            'timestamp': datetime.now().isoformat(),
            'session_id': str(uuid.uuid4())
            # Removed large metadata field
        }

    def generate_order_event(self):
        """Generate order and transaction events"""
        user = random.choice(self.users)
        # Reduced number of items per order
        num_items = random.randint(1, 2)
        order_items = []
        total_amount = 0
        
        for _ in range(num_items):
            product = random.choice(self.products)
            quantity = random.randint(1, 2)
            item_total = quantity * product['price']
            total_amount += item_total
            
            order_items.append({
                'product_id': product['product_id'],
                'quantity': quantity,
                'unit_price': product['price'],
                'total': item_total
            })
        
        return {
            'order_id': str(uuid.uuid4()),
            'user_id': user['user_id'],
            'timestamp': datetime.now().isoformat(),
            'items': order_items,
            'total_amount': round(total_amount, 2),
            # Simplified address to reduce message size
            'shipping_address': fake.city() + ", " + fake.country(),
            'payment_method': random.choice(['credit_card', 'paypal', 'bank_transfer']),
            'status': 'created'
        }

    def generate_inventory_event(self):
        """Generate inventory update events"""
        product = random.choice(self.products)
        change_type = random.choice(['restock', 'adjustment', 'sale'])
        quantity_change = random.randint(-5, 20) if change_type != 'sale' else -random.randint(1, 3)
        
        return {
            'inventory_event_id': str(uuid.uuid4()),
            'product_id': product['product_id'],
            'timestamp': datetime.now().isoformat(),
            'change_type': change_type,
            'quantity_change': quantity_change,
            'new_quantity': max(0, product['inventory'] + quantity_change),
            'warehouse_id': str(uuid.uuid4()),
            'reason': f'{change_type.title()} adjustment'
        }

    def run(self, events_per_second=5):
        """Main loop to generate and send events to Kafka"""
        try:
            # Create topics if they don't exist
            topics = ['user_events', 'order_events', 'inventory_events']
            for topic in topics:
                try:
                    # This will send a metadata request that will create the topic if auto.create.topics.enable=true
                    self.producer.send(topic, {"test": "test"})
                except Exception as e:
                    logger.error(f"Error creating topic {topic}: {e}")
            
            self.producer.flush()
            logger.info(f"Starting event generation at {events_per_second} events per second")
            
            event_count = 0
            start_time = time.time()
            
            while True:
                try:
                    # Generate different types of events with different probabilities
                    for _ in range(events_per_second):
                        event_type = random.choices(
                            ['user', 'order', 'inventory'],
                            weights=[0.7, 0.2, 0.1]
                        )[0]
                        
                        if event_type == 'user':
                            event = self.generate_user_event()
                            topic = 'user_events'
                        elif event_type == 'order':
                            event = self.generate_order_event()
                            topic = 'order_events'
                        else:
                            event = self.generate_inventory_event()
                            topic = 'inventory_events'
                        
                        # Send event to Kafka
                        future = self.producer.send(topic, event)
                        # For debugging, wait for the result and log any errors
                        # result = future.get(timeout=5)
                        event_count += 1
                    
                    # Flush every 10 seconds instead of every batch
                    current_time = time.time()
                    if current_time - start_time > 10:
                        logger.info(f"Generated {event_count} events in the last 10 seconds")
                        self.producer.flush()
                        event_count = 0
                        start_time = current_time
                    
                    time.sleep(1)  # Wait for 1 second before the next batch
                    
                except Exception as e:
                    logger.error(f"Error during event generation: {e}", exc_info=True)
                    time.sleep(5)  # Wait before retrying if there's an error
                
        except KeyboardInterrupt:
            logger.info("Stopping data generation...")
        finally:
            logger.info("Closing Kafka producer...")
            self.producer.flush()
            self.producer.close()
            logger.info("Producer closed successfully")

if __name__ == "__main__":
    # Get Kafka bootstrap servers from environment variable or use default
    bootstrap_servers = os.environ.get('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9093,localhost:9094,localhost:9095')
    
    # Convert string to list if needed
    if isinstance(bootstrap_servers, str):
        bootstrap_servers = bootstrap_servers.split(',')
    import json
import random
import time
import os
from datetime import datetime
from faker import Faker
from faker_commerce import Provider
from kafka import KafkaProducer
import uuid
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Faker with commerce provider
fake = Faker()
fake.add_provider(Provider)

class EcommerceDataGenerator:
    def __init__(self, bootstrap_servers):
        logger.info(f"Connecting to Kafka at {bootstrap_servers}")
        
        # More reasonable producer configuration
        # Fixed acks parameter to be an integer 1 instead of string '1'
        self.producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            value_serializer=lambda x: json.dumps(x).encode('utf-8'),
            compression_type='gzip',
            batch_size=16384,  # 16KB batch size
            linger_ms=50,      # Wait 50ms to batch messages
            max_request_size=1048576,  # 1MB max request size
            buffer_memory=33554432,    # 32MB buffer
            acks=1,            # Using integer 1 instead of string '1'
            retries=3,
            retry_backoff_ms=100
        )
        
        logger.info("Generating sample data")
        # Initialize sample data - reduced product and user counts for testing
        self.products = self._generate_sample_products(20)
        self.users = self._generate_sample_users(50)
        logger.info(f"Generated {len(self.products)} products and {len(self.users)} users")
        
    def _generate_sample_products(self, num_products):
        return [{
            'product_id': str(uuid.uuid4()),
            'name': fake.ecommerce_name(),
            'category': fake.ecommerce_category(),
            'price': round(random.uniform(10, 1000), 2),
            'inventory': random.randint(0, 100)
        } for _ in range(num_products)]
    
    def _generate_sample_users(self, num_users):
        return [{
            'user_id': str(uuid.uuid4()),
            'name': fake.name(),
            'email': fake.email(),
            'location': fake.city()
        } for _ in range(num_users)]

    def generate_user_event(self):
        """Generate user browsing and interaction events"""
        user = random.choice(self.users)
        product = random.choice(self.products)
        event_type = random.choice([
            'page_view', 'search', 'add_to_cart', 'remove_from_cart',
            'add_to_wishlist', 'product_click', 'category_view'
        ])
        
        # Simplified event with smaller size
        return {
            'event_id': str(uuid.uuid4()),
            'event_type': event_type,
            'user_id': user['user_id'],
            'product_id': product['product_id'],
            'timestamp': datetime.now().isoformat(),
            'session_id': str(uuid.uuid4())
        }

    def generate_order_event(self):
        """Generate order and transaction events"""
        user = random.choice(self.users)
        # Reduced number of items per order
        num_items = random.randint(1, 2)
        order_items = []
        total_amount = 0
        
        for _ in range(num_items):
            product = random.choice(self.products)
            quantity = random.randint(1, 2)
            item_total = quantity * product['price']
            total_amount += item_total
            
            order_items.append({
                'product_id': product['product_id'],
                'quantity': quantity,
                'unit_price': product['price'],
                'total': item_total
            })
        
        return {
            'order_id': str(uuid.uuid4()),
            'user_id': user['user_id'],
            'timestamp': datetime.now().isoformat(),
            'items': order_items,
            'total_amount': round(total_amount, 2),
            # Simplified address to reduce message size
            'shipping_address': fake.city() + ", " + fake.country(),
            'payment_method': random.choice(['credit_card', 'paypal', 'bank_transfer']),
            'status': 'created'
        }

    def generate_inventory_event(self):
        """Generate inventory update events"""
        product = random.choice(self.products)
        change_type = random.choice(['restock', 'adjustment', 'sale'])
        quantity_change = random.randint(-5, 20) if change_type != 'sale' else -random.randint(1, 3)
        
        return {
            'inventory_event_id': str(uuid.uuid4()),
            'product_id': product['product_id'],
            'timestamp': datetime.now().isoformat(),
            'change_type': change_type,
            'quantity_change': quantity_change,
            'new_quantity': max(0, product['inventory'] + quantity_change),
            'warehouse_id': str(uuid.uuid4()),
            'reason': f'{change_type.title()} adjustment'
        }

    def run(self, events_per_second=5):
        """Main loop to generate and send events to Kafka"""
        try:
            # Create topics if they don't exist
            topics = ['user_events', 'order_events', 'inventory_events']
            for topic in topics:
                try:
                    # This will send a metadata request that will create the topic if auto.create.topics.enable=true
                    self.producer.send(topic, {"test": "test"})
                except Exception as e:
                    logger.error(f"Error creating topic {topic}: {e}")
            
            self.producer.flush()
            logger.info(f"Starting event generation at {events_per_second} events per second")
            
            event_count = 0
            start_time = time.time()
            
            while True:
                try:
                    # Generate different types of events with different probabilities
                    for _ in range(events_per_second):
                        event_type = random.choices(
                            ['user', 'order', 'inventory'],
                            weights=[0.7, 0.2, 0.1]
                        )[0]
                        
                        if event_type == 'user':
                            event = self.generate_user_event()
                            topic = 'user_events'
                        elif event_type == 'order':
                            event = self.generate_order_event()
                            topic = 'order_events'
                        else:
                            event = self.generate_inventory_event()
                            topic = 'inventory_events'
                        
                        # Send event to Kafka
                        future = self.producer.send(topic, event)
                        event_count += 1
                    
                    # Flush every 10 seconds instead of every batch
                    current_time = time.time()
                    if current_time - start_time > 10:
                        logger.info(f"Generated {event_count} events in the last 10 seconds")
                        self.producer.flush()
                        event_count = 0
                        start_time = current_time
                    
                    time.sleep(1)  # Wait for 1 second before the next batch
                    
                except Exception as e:
                    logger.error(f"Error during event generation: {e}", exc_info=True)
                    time.sleep(5)  # Wait before retrying if there's an error
                
        except KeyboardInterrupt:
            logger.info("Stopping data generation...")
        finally:
            logger.info("Closing Kafka producer...")
            self.producer.flush()
            self.producer.close()
            logger.info("Producer closed successfully")

if __name__ == "__main__":
    # Get Kafka bootstrap servers from environment variable or use default
    bootstrap_servers = os.environ.get('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9093,localhost:9094,localhost:9095')
    
    # Convert string to list if needed
    if isinstance(bootstrap_servers, str):
        bootstrap_servers = bootstrap_servers.split(',')
    
    # Get events per second from environment variable or use default
    events_per_second = int(os.environ.get('EVENTS_PER_SECOND', '5'))
    
    logger.info(f"Starting with bootstrap_servers={bootstrap_servers}, events_per_second={events_per_second}")
    
    # Create and run the generator
    generator = EcommerceDataGenerator(bootstrap_servers)
    generator.run(events_per_second=events_per_second)
    # Get events per second from environment variable or use default
    events_per_second = int(os.environ.get('EVENTS_PER_SECOND', '5'))
    
    logger.info(f"Starting with bootstrap_servers={bootstrap_servers}, events_per_second={events_per_second}")
    
    # Create and run the generator
    generator = EcommerceDataGenerator(bootstrap_servers)
    generator.run(events_per_second=events_per_second)