#!/bin/bash

# Stop and remove the data generator container if it exists
echo "Checking for existing data generator container..."
if [ "$(docker ps -a -q -f name=data-generator)" ]; then
    echo "Removing existing data generator container..."
    docker stop data-generator > /dev/null 2>&1
    docker rm data-generator > /dev/null 2>&1
fi

# Stop and remove any existing Kafka containers
echo "Stopping any existing Kafka containers..."
docker-compose down -v

# Start the Kafka cluster
echo "Starting Kafka cluster..."
docker-compose up -d

# Wait for Kafka to be fully up and running
echo "Waiting for Kafka to be ready..."
echo "This may take up to 60 seconds..."
# First wait for brokers to be up
for i in {1..30}; do
    if docker-compose exec -T kafka-1 kafka-broker-api-versions --bootstrap-server kafka-1:9092 > /dev/null 2>&1; then
        echo "Kafka brokers are up!"
        break
    fi
    if [ $i -eq 30 ]; then
        echo "Timeout waiting for Kafka to start. Check docker logs for details."
        exit 1
    fi
    echo -n "."
    sleep 2
done

# Create the network if it doesn't exist
echo "Ensuring Docker network exists..."
if ! docker network inspect ecommerce-analytics-network > /dev/null 2>&1; then
    echo "Creating Docker network..."
    docker network create ecommerce-analytics-network
fi

# Connect Kafka containers to the network if they're not already connected
echo "Ensuring Kafka containers are connected to the network..."
for container in kafka-1 kafka-2 kafka-3; do
    if ! docker network inspect ecommerce-analytics-network | grep -q "$container"; then
        echo "Connecting $container to the network..."
        docker network connect ecommerce-analytics-network $container
    fi
done

# Create the Kafka topics (if they don't already exist)
echo "Creating Kafka topics if they don't exist..."
for topic in user_events order_events inventory_events; do
    if ! docker-compose exec -T kafka-1 kafka-topics --list --bootstrap-server kafka-1:9092 | grep -q "^$topic$"; then
        echo "Creating topic: $topic"
        docker-compose exec -T kafka-1 kafka-topics --create --bootstrap-server kafka-1:9092 --replication-factor 3 --partitions 3 --topic $topic
    else
        echo "Topic $topic already exists"
    fi
done

# Build the data generator Docker image
echo "Building data generator Docker image..."
docker build -t ecommerce-data-generator .

# Run the data generator
echo "Running data generator..."
docker run -d \
  --name data-generator \
  --network ecommerce-analytics-network \
  -e KAFKA_BOOTSTRAP_SERVERS=kafka-1:9092,kafka-2:9092,kafka-3:9092 \
  -e EVENTS_PER_SECOND=5 \
  ecommerce-data-generator

echo ""
echo "Setup complete! You can monitor:"
echo "- Kafka Control Center: http://localhost:9021"
echo "- Data generator logs: docker logs -f data-generator"
echo ""
echo "To stop everything, run: docker-compose down && docker stop data-generator"